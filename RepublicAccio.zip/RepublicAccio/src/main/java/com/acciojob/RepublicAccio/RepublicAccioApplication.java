package com.acciojob.RepublicAccio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RepublicAccioApplication {

	public static void main(String[] args) {
		SpringApplication.run(RepublicAccioApplication.class, args);
	}

}
